package com.example.simpleloginapp;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class activity_account extends AppCompatActivity {

    // Declare views
    TextView titleTextView;
    TextView notificationTitleTextView;
    TextView notificationMessageTextView;
    ImageView travelStatsImageView;
    TextView travelStatsTextView;
    ImageView previousTripsImageView;
    TextView previousTripsTextView;
    ImageView walletImageView;
    TextView walletTextView;
    TextView helpTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        titleTextView = findViewById(R.id.titleTextView);
        notificationTitleTextView = findViewById(R.id.notificationTitleTextView);
        notificationMessageTextView = findViewById(R.id.notificationMessageTextView);
        travelStatsImageView = findViewById(R.id.travelStatsImageView); // Update ID if necessary
        travelStatsTextView = findViewById(R.id.travelStatsTextView); // Update ID if necessary
        previousTripsImageView = findViewById(R.id.previousTripsImageView); // Update ID if necessary
        previousTripsTextView = findViewById(R.id.previousTripsTextView); // Update ID if necessary
        walletImageView = findViewById(R.id.walletImageView); // Update ID if necessary
        walletTextView = findViewById(R.id.walletTextView); // Update ID if necessary
        helpTextView = findViewById(R.id.helpTextView);

        titleTextView.setText("Account");
        notificationTitleTextView.setText("Muhammad Omar Zahid");
        notificationMessageTextView.setText("muhammadomarzahid@gmail.com");

    }
}
