package com.example.simpleloginapp;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class activity_alerts extends AppCompatActivity {

    TextView titleTextView;
    TextView notificationTitleTextView;
    TextView notificationMessageTextView;
    TextView updateLanguageLinkTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alerts);

        titleTextView = findViewById(R.id.titleTextView);
        notificationTitleTextView = findViewById(R.id.notificationTitleTextView);
        notificationMessageTextView = findViewById(R.id.notificationMessageTextView);
        updateLanguageLinkTextView = findViewById(R.id.updateLanguageLinkTextView);

        updateLanguageLinkTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity_alerts.this, "Navigating to language settings", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
